const express = require("express");
const path = require("path");
const mysql = require("mysql");
const dotenv = require("dotenv");

dotenv.config({ path: "./.env" });

const app = express();

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded({ extended: false }));

// Parse JSON bodies (as sent by API clients)
app.use(express.json());

// Set up the view engine and static directory
const publicDirectory = path.join(__dirname, "./public");
app.use(express.static(publicDirectory));
app.set("view engine", "hbs");

// Database configuration
const db = mysql.createConnection({
  host: process.env.DATABASE_HOST,
  user: process.env.DATABASE_USER,
  password: process.env.DATABASE_PASSWORD,
  database: process.env.DATABASE,
});

// Connect to the database
db.connect((error) => {
  if (error) {
    console.log(error);
  } else {
    console.log("MYSQL Connected...");
  }
});



// Define urlencodedParser
const urlencodedParser = express.urlencoded({ extended: false });

// Routes
app.get("/", function (req, res) {
  db.query("SELECT * FROM users", function (err, data) {
    if (err) return console.log(err);
    res.render("index", {
      users: data,
    });
  });
});

// Render the form for adding data
app.get("/index", function (req, res) {
  res.render("index");
});

// Add data to the database
app.post("/index/add", urlencodedParser, function (req, res) {
  if (!req.body) return res.sendStatus(400);
  const email = req.body.email;
  const password = req.body.password;
  db.query(
    "INSERT INTO users (email, password) VALUES (?,?)",
    [email, password],
    function (err, data) {
      if (err) return console.log(err);
      res.redirect("/");
    }
  );
});

// Render the form for editing data
app.get("/index/edit/:id", function (req, res) {
  const id = req.params.id;
  db.query("SELECT * FROM users WHERE id=?", [id], function (err, data) {
    if (err) return console.log(err);
    res.render("edit", {
      user: data[0],
    });
  });
});

// Update data in the database
app.post("/index/update/:id", urlencodedParser, function (req, res) {
  if (!req.body) return res.sendStatus(400);
  const email = req.body.email;
  const password = req.body.password;
  const id = req.params.id;
  db.query(
    "UPDATE users SET email=?, password=? WHERE id=?",
    [email, password, id],
    function (err, data) {
      if (err) return console.log(err);
      res.redirect("/");
    }
  );
});

// Delete data from the database
app.post("/index/delete/:id", function (req, res) {
  const id = req.params.id;
  db.query("DELETE FROM users WHERE id=?", [id], function (err, data) {
    if (err) return console.log(err);
    res.redirect("/");
  });
});

//Define Routers
app.use('/',require('./routes/pages'))
app.use('/auth',require('./routes/auth'))

// Start the server
app.listen(5000, () => {
  console.log("Server started on port 5000");
});
