const mysql = require("mysql");
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE 
});

exports.register = (req, res) =>{
    console.log(req.body);
    const { email, password, passwordConfirm } = req.body;

    db.query('SELECT email FROM users WHERE email = ?', [email], async (error, results) => {
        if (error) {
            console.log(error);
        }

        if (results.length > 0) {
            return res.render('register', {
                message: 'That email is already in use'
            });
        } else if (password !== passwordConfirm) {
            return res.render('register', {
                message: 'Password do not match'
            });
        }

        let hashedPassword = await bcrypt.hash(password, 8);
        console.log(hashedPassword);
        db.query('INSERT INTO users SET ?', { email: email, password: hashedPassword }, (error, results) => {
            if (error) {
                console.log(error);
            } else {
                console.log(results);
                return res.render('register', {
                    message: 'User registered'
                });
            }
        });
    });
};

exports.login = async (req, res) => {
    console.log(req.body);
    const { email, password } = req.body;

    db.query('SELECT * FROM users WHERE email = ?', [email], async (error, results) => {
        if (error) {
            console.log(error);
            return res.status(500).send('Server error');
        }

        if (results.length === 0) {
            return res.render('login', {
                message: 'Email or password is incorrect'
            });
        }

        const user = results[0];
        const isPasswordMatch = await bcrypt.compare(password, user.password);

        if (!isPasswordMatch) {
            return res.render('login', {
                message: 'Email or password is incorrect'
            });
        }

        const token = jwt.sign({ userId: user.id }, 'your_secret_key', { expiresIn: '1h' });
        res.cookie('token', token, { httpOnly: true });

        return res.render('login', {
            message: 'Logged in successfully'
        });
    });
};

exports.index = async (req, res) => {
    db.query('SELECT * FROM users', (error, results) => {
        if (error) {
            console.error('Error:', error);
            res.status(500).send('Failed to fetch users');
        } else {
            res.render('index', { users: results });
        }
    });
};

exports.updateUser = async (req, res) => {
    const { userId, email, password } = req.body;

    db.query('UPDATE users SET email = ?, password = ? WHERE id = ?', [email, password, userId], (error, results) => {
        if (error) {
            console.error('Error:', error);
            res.status(500).send('Failed to update user');
        } else {
            res.status(200).send('User updated successfully');
        }
    });
};

exports.deleteUser = async (req, res) => {
    const userId = req.params.userId;

    db.query('DELETE FROM users WHERE id = ?', [userId], (error, results) => {
        if (error) {
            console.error('Error:', error);
            res.status(500).send('Failed to delete user');
        } else {
            res.status(200).send('User deleted successfully');
        }
    });
};
